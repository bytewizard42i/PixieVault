#!/usr/bin/env bash
# Alternative installation script for systems with internet access
set -e
sudo apt-get update
sudo apt-get install -y python3-pip python3-tk python3-dev libjpeg-dev zlib1g-dev python3-pil python3-pil.imagetk mpv
pip3 install --user --upgrade pip
pip3 install --user Pillow
echo "✨ Dependencies installed! Run: python3 src/app.py"
