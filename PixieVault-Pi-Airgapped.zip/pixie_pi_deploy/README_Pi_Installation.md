# PixieVault Raspberry Pi Installation Guide

## For Airgapped Raspberry Pi Systems

This package contains everything needed to run PixieVault on a Raspberry Pi without internet access.

### Contents
- `src/` - PixieVault application source code
- `data/` - Configuration files
- `media/` - Images and assets
- `scripts/` - Utility scripts
- `services/` - Systemd service files for auto-start
- `wheels/` - Python package wheels for offline installation
- `install_offline.sh` - Main installation script

### Installation Steps

1. **Copy this folder to your Pi**
   ```bash
   # Extract the zip file to your desired location, e.g.:
   cd ~/Desktop
   unzip PixieVault-Pi-Airgapped.zip
   cd PixieVault-Pi-Airgapped
   ```

2. **Make scripts executable**
   ```bash
   chmod +x *.sh
   chmod +x scripts/*.sh
   ```

3. **Run the offline installation**
   ```bash
   ./install_offline.sh
   ```

4. **Launch PixieVault**
   ```bash
   python3 src/app.py
   ```

### Auto-Start Setup (Optional)

To have PixieVault start automatically on boot:

```bash
sudo cp services/pixie-app.service /etc/systemd/system/
sudo systemctl enable pixie-app.service
sudo systemctl start pixie-app.service
```

### Troubleshooting

- **PIL Import Error**: The offline installer includes Pillow wheels. If you still get import errors, try: `pip3 install --user --force-reinstall wheels/pillow*.whl`
- **Permission Issues**: Make sure all `.sh` files are executable with `chmod +x`
- **Display Issues**: Ensure you're running on a Pi with a desktop environment (not headless)

### System Requirements

- Raspberry Pi 3B+ or newer
- Raspberry Pi OS (Debian-based)
- Desktop environment (LXDE, GNOME, etc.)
- At least 1GB free space

### Features

- Password management with encryption
- Touch-friendly interface optimized for Pi touchscreens
- Custom fields support
- Search and filtering
- Automatic backups
- No internet required after installation
