#!/usr/bin/env bash
# PixieVault Offline Installation Script for Raspberry Pi
# This script installs all dependencies for an airgapped Pi

set -e

echo "🧚‍♀️ PixieVault Pi Offline Installation Starting..."

# Update package lists (requires internet for first time, but packages are cached)
echo "Updating package lists..."
sudo apt-get update

# Install system dependencies
echo "Installing system packages..."
sudo apt-get install -y python3-pip python3-tk python3-dev libjpeg-dev zlib1g-dev python3-pil python3-pil.imagetk mpv

# Upgrade pip
echo "Upgrading pip..."
pip3 install --user --upgrade pip

# Install Python packages from local wheels
echo "Installing Python dependencies from local wheels..."
if [ -d "wheels" ]; then
    pip3 install --user --no-index --find-links wheels/ wheels/*.whl
else
    echo "Warning: wheels directory not found, trying online installation..."
    pip3 install --user Pillow
fi

echo "✨ Installation complete!"
echo ""
echo "To run PixieVault:"
echo "  cd $(pwd)"
echo "  python3 src/app.py"
echo ""
echo "Or use the service scripts in the services/ directory for auto-start."
